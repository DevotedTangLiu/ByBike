package com.example.test;

import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ecloud.pulltozoomview.PullToZoomListViewEx;

/**
 * Author: ZhuWenWu Version V1.0 Date: 2014/9/4 17:11. Description: Modification
 * History: Date Author Version Description
 * --------------------------------------
 * --------------------------------------------- 2014/9/4 ZhuWenWu 1.0 1.0 Why &
 * What is modified:
 */
public class PullToZoomListActivity extends Activity {

	private PullToZoomListViewEx listView;
	// 点赞、评论、分享区域
	RelativeLayout likeButton;
	TextView likeCount;
	RelativeLayout collectButton;
	TextView collectCount;
	TextView distance;
	TextView timeLong;
	TextView publishTime;
	TextView exerciseTitle;
	TextView exerciseRouteAddress;
	TextView exerciseTime;
	TextView exerciseDetail;
	TextView exercisePrice;
	TextView deadline;
	TextView applyUserCount;
	TextView discussCount;
	Button discussButton;

	// 评论列表
	List<ContentValues> discussValueList = null;
	ExerciseDiscussListAdapter discussAdapter = null;

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pull_to_zoom_list_view);
		getActionBar().setDisplayHomeAsUpEnabled(true);

		listView = (PullToZoomListViewEx) findViewById(R.id.listview);

		discussValueList = new ArrayList<ContentValues>();
		discussAdapter = new ExerciseDiscussListAdapter(
				PullToZoomListActivity.this, discussValueList);
		listView.setAdapter(discussAdapter);

		ContentValues v0 = new ContentValues();
		v0.put("userName", "ChaolotteYam");
		v0.put("discussContent", "有爱。");
		v0.put("avater",
				"http://t11.baidu.com/it/u=1610160448,1299213022&fm=56");
		v0.put("discussTime", "10.28 14:30");
		discussValueList.add(v0);
		// 填充评论列表
		for (int i = 0; i < 2; i++) {
			ContentValues v1 = new ContentValues();
			v1.put("userName", "ChaolotteYam");
			v1.put("discussContent", "有爱。");
			v1.put("avater",
					"http://t11.baidu.com/it/u=1610160448,1299213022&fm=56");
			v1.put("discussTime", "10.28 14:30");
			discussValueList.add(v1);
			ContentValues v2 = new ContentValues();
			v2.put("userName", "Jeronmme_1221");
			v2.put("discussContent", "今天倍儿爽！");
			v2.put("avater",
					"http://t11.baidu.com/it/u=1620038746,1252150868&fm=56");
			v2.put("discussTime", "10.28 14:48");
			discussValueList.add(v2);
		}
		discussAdapter.notifyDataSetChanged();

		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Log.e("zhuwenwu", "position = " + position);
			}
		});

		DisplayMetrics localDisplayMetrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(localDisplayMetrics);
		int mScreenHeight = localDisplayMetrics.heightPixels;
		int mScreenWidth = localDisplayMetrics.widthPixels;
		AbsListView.LayoutParams localObject = new AbsListView.LayoutParams(
				mScreenWidth, (int) (9.0F * (mScreenWidth / 16.0F)));
		listView.setHeaderLayoutParams(localObject);
		listView.getHeaderView().setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				System.out.println("------------header---------------");
				v.onTouchEvent(event);
				return true;
			}
		});
		listView.getZoomView().setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				System.out.println("------------zoom---------------");
				v.onTouchEvent(event);
				return true;
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.list_view, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == android.R.id.home) {
			finish();
			return true;
		} else if (id == R.id.action_normal) {
			listView.setParallax(false);
			return true;
		} else if (id == R.id.action_parallax) {
			listView.setParallax(true);
			return true;
		} else if (id == R.id.action_show_head) {
			listView.setHideHeader(false);
			return true;
		} else if (id == R.id.action_hide_head) {
			listView.setHideHeader(true);
			return true;
		} else if (id == R.id.action_disable_zoom) {
			listView.setZoomEnabled(false);
			return true;
		} else if (id == R.id.action_enable_zoom) {
			listView.setZoomEnabled(true);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
