/** Automatically generated file. DO NOT MODIFY */
package com.ecloud.pulltozoomview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}